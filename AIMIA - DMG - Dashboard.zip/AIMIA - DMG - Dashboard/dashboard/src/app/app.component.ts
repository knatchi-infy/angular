import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import { getDMGRedemptionData } from "./actions/DMG.action";
import { DMGDataEffects } from './effects/DMG.effect';
import { Observable } from "rxjs";

import {DataServices} from './services/DMG.service';
import {Redemption} from './RedemData';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  private earnTitle: string;
  private earnValue: number;
  private earnComponent: string;

  private spendTitle: string;
  private spendValue: number;
  private spendComponent: string;

  private dashFooter: string;
  private apiresponseTitle: string;
  private apiresponseValue: number;
  private apiresponsePeriod: string;
  private apiComponent: string;

  private newcustomerTitle: string;
  private newcustomerValue: number;
  private linkcustomerTitle: string;
  private linkcustomerValue: number;
  private testData: Observable<any>;

  //constructor(){
  constructor(private store : Store<any>,private dmgEffects: DMGDataEffects, private service: DataServices, data: Redemption){
    this.earnTitle = "Points Accrued";
    this.earnValue = 12540;
    this.earnComponent = "earn";

    this.spendTitle = "Points Spend";
    this.spendValue = 23109;
    this.spendComponent = "spend";

    this.dashFooter = "Transaction Count: 3<br/>Transaction Date: 17-Jul-17";
    this.apiresponseTitle = "API Response";
    this.apiresponseValue = 1.86;
    this.apiresponsePeriod = "Seconds";


    this.newcustomerTitle = "New Customers";
    this.newcustomerValue = 83;
    this.linkcustomerTitle = "Linked Customers";
    this.linkcustomerValue = 21;

    this.store.dispatch(getDMGRedemptionData());
    this.testData = store.select("DMG");

    //console.log(service.RedemData());
    let val: Promise<Redemption> = service.RedemData();
    console.log(val);
    service.RedemData().then(resp => {
      data.count = resp.count,
      data.date = resp.date,
      data.points = resp.points,
      data.sponsor = resp.sponsor
    });
    console.log(data);
  }

  ngOnInit(){
    
  }
}