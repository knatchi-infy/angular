export class Redemption{
    sponsor: string;
    count: number;
    date: string;
    points: number;
}