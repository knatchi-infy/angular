import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { DashComponentComponent } from './dash-component/dash-component.component';
import { DonutChartComponentComponent } from './donut-chart-component/donut-chart-component.component';
import { DataServices } from './services/DMG.service';
import { DMGDataEffects } from './effects/DMG.effect';
import { dmgReducer } from './reducers/DMG.reducer'
import { Redemption } from './RedemData';

import { EffectsModule } from "@ngrx/effects";
import { StoreModule } from '@ngrx/store';

@NgModule({
  declarations: [
    AppComponent,
    DashComponentComponent,
    DonutChartComponentComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    StoreModule.provideStore({DMG: dmgReducer}),
    EffectsModule.run(DMGDataEffects),
  ],
  providers: [DataServices,Redemption],
  bootstrap: [AppComponent]
})
export class AppModule { }
