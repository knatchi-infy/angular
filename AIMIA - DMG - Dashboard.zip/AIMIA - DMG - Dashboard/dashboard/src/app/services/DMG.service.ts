import { Component, Input, Injectable } from '@angular/core';
import { Http, HttpModule, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import {Redemption} from '../RedemData';

@Injectable()
export class DataServices {

    private result:any;
    private token: any;
    constructor(private http: Http) {
    }

    RedemptionData():any {
        return this.http.get('../../assets/data/DMG_Input.json');
    }

/*
    tryJSONAPICall() {
        return new Promise((resolve,reject) => {
            this.http.get
        })
    }
*/

    RedemData():Promise<Redemption>{
        return this.http.get('../../assets/data/DMG_Input.json')
                        .toPromise()
                        .then(resp => resp.json());
    }
}