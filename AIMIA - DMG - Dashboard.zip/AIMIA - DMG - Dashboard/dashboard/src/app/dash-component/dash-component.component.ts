import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-component',
  templateUrl: './dash-component.component.html',
  styleUrls: ['./dash-component.component.css']
})
export class DashComponentComponent implements OnInit {

  @Input() private dashTitle;
  @Input() private dashValue;
  @Input() private dashFooter;
  @Input() private dashComponent;
  @Input() private dashGraph;
  @Input() private dmgData;

  private gValue: number;
  private gComp: String;
  private enableGraph: boolean;

  constructor(){}

  ngOnInit() {
    //console.log("Init");
    //console.log(this.dmgData);
    this.gValue = this.dashValue;
    this.gComp = this.dashComponent;
    this.enableGraph = this.dashGraph;
  }

  ngOnChanges(changes) {
    //console.log("OnChange");
    //console.log(changes);
  }

}
