import { ActionReducer, Action } from '@ngrx/store';

import { 
    GET_DMG_REDEMPTION_DATA, 
    GET_DMG_REDEMPTION_DATA_SUCCESS } from '../actions/DMG.action';

export const initialState = {}

export function dmgReducer(state = initialState, action: Action) : any {
    switch (action.type) {
        case GET_DMG_REDEMPTION_DATA:
            return Object.assign({}, state, {pending: true, error: null})

        case GET_DMG_REDEMPTION_DATA_SUCCESS:
            //console.log(action.payload);
            return Object.assign({}, state, {data: action.payload, pending: false})

        default:
            return state;
    }
}