import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonutChartComponentComponent } from './donut-chart-component.component';

describe('DonutChartComponentComponent', () => {
  let component: DonutChartComponentComponent;
  let fixture: ComponentFixture<DonutChartComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DonutChartComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonutChartComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
