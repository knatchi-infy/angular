import { Component, Input, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-donut-chart-component',
  templateUrl: './donut-chart-component.component.html',
  styleUrls: ['./donut-chart-component.component.css']
})
export class DonutChartComponentComponent implements OnInit {

  @Input() private graphValue;
  @Input() private graphComponent;
  private offset: number;

  constructor() { }

  ngOnInit() {
    let denom_len = this.graphValue.toString().length-1;
    let denom = Math.ceil(this.graphValue/Math.pow(10,denom_len));
    this.offset = (this.graphValue/(Math.pow(10,denom_len)*denom));
    if(this.offset == 1)
      this.offset = (this.graphValue/((Math.pow(10,denom_len)*denom)+Math.pow(10,denom_len)));
    this.offset = 564 - (this.offset * 400);
  }

  ngAfterViewInit() {
    $("#graphCircle_"+this.graphComponent).attr('stroke-dashoffset',this.offset);
  }

}
