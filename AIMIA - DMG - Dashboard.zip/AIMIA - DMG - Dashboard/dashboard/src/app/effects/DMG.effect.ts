import { Injectable } from "@angular/core";
import { Actions, Effect } from "@ngrx/effects";
import { Observable } from "rxjs";
import {
        GET_DMG_REDEMPTION_DATA,
        GET_DMG_REDEMPTION_DATA_SUCCESS,
        GET_DMG_REDEMPTION_DATA_ERROR
    } from "../actions/DMG.action";
import { DataServices } from "../services/DMG.service";

@Injectable()
export class DMGDataEffects {
    constructor( private actions$ : Actions, private dataService : DataServices ) {
    }

    @Effect() getDMGRedemptionData$ = this.actions$
        .ofType(GET_DMG_REDEMPTION_DATA)
        .switchMap(payload => this.dataService.RedemptionData()
                                .map((data) => data.json()[0])
                                .map(data => ({type: GET_DMG_REDEMPTION_DATA_SUCCESS, payload: data }))
                                .catch(() => Observable.of({type: GET_DMG_REDEMPTION_DATA_ERROR})))
}