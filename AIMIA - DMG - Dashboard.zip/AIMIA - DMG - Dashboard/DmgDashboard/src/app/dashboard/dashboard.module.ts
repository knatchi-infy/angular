import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { EffectsModule } from "@ngrx/effects";
import { HttpModule } from '@angular/http';

import { DashboardPageComponent } from '../dashboard/containers/dashboard-page.component';
import { DashingComponent } from '../dashboard/components/dashing-tiles/dashing.component';
import { DashboardService } from './services/dashboard.service';
import { DashboardEffect } from './effects/dashboard.effect';
import { DonutGraphComponent } from './components/donut-graph/donut-graph.component';
import { FooterComponent } from './components/footer-context/footer-context.component';

@NgModule({
  declarations: [
    DashboardPageComponent,
    DashingComponent,
    DonutGraphComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    EffectsModule.run(DashboardEffect)
  ],
  providers: [DashboardService],
  bootstrap: [DashboardPageComponent]
})
export class DashboardModule { }