import { Injectable } from "@angular/core";
import { Actions, Effect } from "@ngrx/effects";
import { Observable } from "rxjs";
import {
        GET_DASHBOARD_ACCRUE_DATA,
        GET_DASHBOARD_ACCRUE_DATA_SUCCESS,
        GET_DASHBOARD_ACCRUE_DATA_ERROR,
        GET_DASHBOARD_SPEND_DATA,
        GET_DASHBOARD_SPEND_DATA_SUCCESS,
        GET_DASHBOARD_SPEND_DATA_ERROR,
        GET_DASHBOARD_CUST_ENROL,
        GET_DASHBOARD_CUST_ENROL_SUCCESS,
        GET_DASHBOARD_CUST_ENROL_ERROR
    } from "../actions/dashboard.action";
import { DashboardService } from "../services/dashboard.service";

@Injectable()
export class DashboardEffect {
    constructor( private actions$ : Actions, private dashService : DashboardService ) {
    }

    @Effect() getPointsAccrueData$ = this.actions$
        .ofType(GET_DASHBOARD_ACCRUE_DATA)
        .switchMap(payload => this.dashService.PointsAccruedDetails()
                                .map((data) => data.json())
                                .map(data => ({type: GET_DASHBOARD_ACCRUE_DATA_SUCCESS, payload: data }))
                                .catch(() => Observable.of({type: GET_DASHBOARD_ACCRUE_DATA_ERROR})))

    @Effect() getPointsSpendData$ = this.actions$
        .ofType(GET_DASHBOARD_SPEND_DATA)
        .switchMap(payload => this.dashService.PointsSpendDetails()
                                .map((data) => data.json())
                                .map(data => ({type: GET_DASHBOARD_SPEND_DATA_SUCCESS, payload: data }))
                                .catch(() => Observable.of({type: GET_DASHBOARD_SPEND_DATA_ERROR})))

    @Effect() getCustomerEnrollmentData$ = this.actions$
        .ofType(GET_DASHBOARD_CUST_ENROL)
        .switchMap(payload => this.dashService.CustomerEnrollmentDetails()
                                .map((data) => data.json())
                                .map(data => ({type: GET_DASHBOARD_CUST_ENROL_SUCCESS, payload: data }))
                                .catch(() => Observable.of({type: GET_DASHBOARD_CUST_ENROL_ERROR})))
}