import { Component } from '@angular/core';
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";

import { getPointsAccrueData, 
  getPointsSpendData,
  getCustomerEnrollmentData } from '../actions/dashboard.action';

@Component({
  templateUrl: './dashboard-page.component.html',
  selector: 'bs-dashboard-page'
})

export class DashboardPageComponent {

  private dashDetail: any;
  private earnTitle: string;
  private earnComponent: string;

  private spendTitle: string;
  private spendComponent: string;

  private enrolTitle: string;
  private enrolComponent: string;

  constructor(private store : Store<any>){
    store.dispatch(getPointsAccrueData());
    store.dispatch(getPointsSpendData());
    store.dispatch(getCustomerEnrollmentData());

    this.dashDetail = store.select("dashboard");
    this.earnTitle = "Points Accrued";
    this.earnComponent = "earn";

    this.spendTitle = "Points Spend";
    this.spendComponent = "spend";

    this.enrolTitle = "Customer Enrollment";
    this.enrolComponent = "enrol";
  }
}