import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-component',
  templateUrl: './dashing.component.html',
  styleUrls: ['./dashing.component.css']
})

export class DashingComponent {

  @Input() dashDetail;
  @Input() dashTitle;
  @Input() component;
  @Input() enableGraph;
  private dashPoints: number;
  //private dashPeriod: string;
  private context: any;

  constructor(){}

  ngOnChanges(changes){
    if(!changes.dashDetail.currentValue.pending){
      if(this.component == 'earn' && changes.dashDetail.currentValue.hasOwnProperty('accrue')){
        this.dashPoints = changes.dashDetail.currentValue.accrue[0].points;
        this.context = [{
          text: "Transaction Count: ",
          value: changes.dashDetail.currentValue.accrue[0].count
        },{
          text: "Transaction Date: ",
          value: changes.dashDetail.currentValue.accrue[0].date
        }]
      }
      if(this.component == 'spend' && changes.dashDetail.currentValue.hasOwnProperty('spend')){
        this.dashPoints = changes.dashDetail.currentValue.spend[0].points;
        //this.dashPeriod = changes.dashDetail.currentValue.spend[0].date;
        this.context = [{
          text: "Transaction Count: ",
          value: changes.dashDetail.currentValue.spend[0].count
        },{
          text: "Transaction Date: ",
          value: changes.dashDetail.currentValue.spend[0].date
        }]
      }
      if(this.component == 'enrol' && changes.dashDetail.currentValue.hasOwnProperty('enrol')){
        this.dashPoints = changes.dashDetail.currentValue.enrol[0].count;
        this.context = [{
          text: "Transaction Date: ",
          value: changes.dashDetail.currentValue.enrol[0].date
        }]
      }
    }
  }
}