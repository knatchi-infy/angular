import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-dash-footer',
  templateUrl: './footer-context.component.html',
  styleUrls: ['./footer-context.component.css']
})

export class FooterComponent {
    
    @Input() context;

    constructor(){}
}