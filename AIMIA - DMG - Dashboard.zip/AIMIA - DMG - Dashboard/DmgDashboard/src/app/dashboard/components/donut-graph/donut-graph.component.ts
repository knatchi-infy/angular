import { Component, Input, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-donut-chart',
  templateUrl: './donut-graph.component.html',
  styleUrls: ['./donut-graph.component.css']
})

export class DonutGraphComponent implements OnInit {

  @Input() private graphValue;
  @Input() private graphComponent;
  private offset: number;

  constructor() { }

  ngOnInit() {}
/*
  ngOnInit() {
    console.log(this.graphValue);
    let denom_len = this.graphValue.toString().length-1;
    let denom = Math.ceil(this.graphValue/Math.pow(10,denom_len));
    this.offset = (this.graphValue/(Math.pow(10,denom_len)*denom));
    if(this.offset == 1)
      this.offset = (this.graphValue/((Math.pow(10,denom_len)*denom)+Math.pow(10,denom_len)));
    this.offset = 564 - (this.offset * 400);
  }
*/

  ngOnChanges(){
    if(this.graphValue && this.graphValue != ''){
      let denom_len = this.graphValue.toString().length-1;
      let denom = Math.ceil(this.graphValue/Math.pow(10,denom_len));
      this.offset = (this.graphValue/(Math.pow(10,denom_len)*denom));
      if(this.offset == 1)
        this.offset = (this.graphValue/((Math.pow(10,denom_len)*denom)+Math.pow(10,denom_len)));
      this.offset = 564 - (this.offset * 400);
      
      $("#graphCircle_"+this.graphComponent).attr('stroke-dashoffset',this.offset);
    }
  }

  ngAfterViewInit() {
    //$("#graphCircle_"+this.graphComponent).attr('stroke-dashoffset',this.CalculateOffSet);
  }
}
