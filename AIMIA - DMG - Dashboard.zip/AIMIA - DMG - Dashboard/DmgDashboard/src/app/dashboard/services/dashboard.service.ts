import { Component, Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class DashboardService {
    
    constructor(private http: Http) {
    }

    PointsAccruedDetails():any {
        return this.http.get('../../../assets/data/DMG_Earned.json');
    }

    PointsSpendDetails():any {
        return this.http.get('../../../assets/data/DMG_Spend.json');
    }

    CustomerEnrollmentDetails():any {
        return this.http.get('../../../assets/data/DMG_Enrollment.json');
    }
}