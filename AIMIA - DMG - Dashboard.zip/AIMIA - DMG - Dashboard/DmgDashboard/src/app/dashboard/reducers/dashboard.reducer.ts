import { ActionReducer, Action } from '@ngrx/store';

import { 
    GET_DASHBOARD_ACCRUE_DATA,
    GET_DASHBOARD_ACCRUE_DATA_SUCCESS, 
    GET_DASHBOARD_SPEND_DATA,
    GET_DASHBOARD_SPEND_DATA_SUCCESS,
    GET_DASHBOARD_CUST_ENROL,
    GET_DASHBOARD_CUST_ENROL_SUCCESS } from '../actions/dashboard.action';

export const initialState = {}

export function dashboardReducer(state = initialState, action: Action) : any {
    //console.log(state);
    //console.log(action);
    switch (action.type) {
        case GET_DASHBOARD_ACCRUE_DATA
            || GET_DASHBOARD_SPEND_DATA
            || GET_DASHBOARD_CUST_ENROL:
            return Object.assign({}, state, {pending: true, error: null})

        case GET_DASHBOARD_ACCRUE_DATA_SUCCESS:
            return Object.assign({}, state, {accrue: action.payload, pending: false})

        case GET_DASHBOARD_SPEND_DATA_SUCCESS:
            return Object.assign({}, state, {spend: action.payload, pending: false})

        case GET_DASHBOARD_CUST_ENROL_SUCCESS:
            return Object.assign({}, state, {enrol: action.payload, pending: false})

        default:
            return state;
    }
}