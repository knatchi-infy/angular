import { NgModule }              from '@angular/core';
import { RouterModule, Routes }  from '@angular/router';

import { DashboardPageComponent } from './dashboard/containers/dashboard-page.component';

const appRoutes: Routes = [{path: '', component: DashboardPageComponent}];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}