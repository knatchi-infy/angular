import { DmgDashboardPage } from './app.po';

describe('dmg-dashboard App', () => {
  let page: DmgDashboardPage;

  beforeEach(() => {
    page = new DmgDashboardPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
